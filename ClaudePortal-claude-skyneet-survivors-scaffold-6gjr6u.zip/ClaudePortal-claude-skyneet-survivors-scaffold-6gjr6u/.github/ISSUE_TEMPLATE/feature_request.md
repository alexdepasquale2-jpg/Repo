---
name: Feature request
about: Propose something new
title: '[feature] '
labels: enhancement
---

## The proposal

## Which pillar does it serve?

<!-- Every feature must serve at least one. A feature serving none is out of scope. -->

- [ ] Greed — "There's more scrap over there."
- [ ] Dread — "Should we turn on NNN?"
- [ ] Power — "This fort is becoming ridiculous."
- [ ] Panic — "The Sancient made them competent."
- [ ] Consequence — "We lost this site, and now somebody else owns it."

## Does it change the battlefield for the next run?

<!-- If yes, say exactly what it writes into the campaign graph. -->

## Does it contradict a locked decision in DESIGN.md?

<!-- If yes, this needs an ADR, not an issue. -->
