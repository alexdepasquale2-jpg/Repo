---
name: Bug report
about: Something behaves differently from what DESIGN.md specifies
title: '[bug] '
labels: bug
---

## What happened

## What DESIGN.md says should happen

<!-- Quote the rule. If no rule covers this, say so — that is a docs/GAPS.md entry, not a bug. -->

## Reproduction

1.
2.
3.

## Scope

- [ ] Session-only (a live run: fort, noise, competence, cards)
- [ ] Campaign (persisted: graph, ownership, stockpiles, feats)

## Environment

- Browser / OS:
- Device (desktop / mobile):
- View mode (top-down / third-person / first-person):
- Campaign save version:
