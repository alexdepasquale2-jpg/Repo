## What this changes

## Which pillar does it serve

<!-- Greed / Dread / Power / Panic / Consequence — at least one. -->

## Design compliance

- [ ] Does not contradict a locked decision in `docs/DESIGN.md`
- [ ] No fort geometry is persisted (forts are session-only — ADR-0002)
- [ ] No flavor label added without a locked mechanical consequence
- [ ] `ui` still does not import `gameplay`

## Verification

- [ ] `npm run typecheck`
- [ ] `npm run lint`
- [ ] `npm run test`
- [ ] `npm run test:e2e` (if behaviour changed)
- [ ] Checked at a mobile viewport
