# noise-heatmap-generator

Samples `NoiseSystem` across a site and writes a heatmap image.

The Dread pillar is made of numbers the player never sees directly, and tuning it blind is how a
"deliberate, dangerous decision" quietly becomes either free or unsurvivable. This renders what a
lit node actually does to a site, per biome, so the propagation and decay values can be argued
about with a picture rather than a hunch.
