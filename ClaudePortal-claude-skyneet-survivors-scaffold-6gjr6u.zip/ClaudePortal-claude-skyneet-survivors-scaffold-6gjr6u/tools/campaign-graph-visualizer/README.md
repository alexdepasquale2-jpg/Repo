# campaign-graph-visualizer

Renders a campaign save as a DOT/SVG graph: sites, edges, current holder, and influence overlap.

Useful for the question the World menu answers slowly and this answers instantly — _what shape has
this campaign actually taken?_ ADR-0001 calls that shape the permanent record, so being able to
diff two saves and see how the front moved is the closest thing this project has to a replay.
